from django.urls import path
from . import views

# 部署的应用名称
app_name = 'Test'

urlpatterns = [
	path('show/', views.show, name='show')
]